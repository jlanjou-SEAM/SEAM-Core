# SEAM v6.4.7 Production Release

SEAM is the primary framework.

Hamiltonian notation is included only as a cross-reference/projection layer. It is not treated as ground truth.

## Reconciled lineage

- Baseline: SEAM v6.2.1 plateau kernel and constants.
- v6.4.7 additions:
  - Delta(H->SEAM) formalism.
  - Hamiltonian cross-reference through log(cosh).
  - Gauge descriptor for QCD-like event descriptions.
  - Fermionic exchange-parity / occupation descriptor for FCI.
  - Operator-space descriptor for SYK.
  - Strongest-candidate N-body numerical example.

## Run

```bash
python -m seam.cli run-suite --out results/seam_v6_4_7_suite.json
python -m seam.cli nbody-example --out results/seam_v6_4_7_nbody_delta.json
```

## Install

```bash
pip install .
seam run-suite
seam nbody-example
```
