# Changelog

## SEAM v6.4.7

Reconciles SEAM v6.2.1 baseline with all additional formulas and fixes developed in session.

### Preserved from v6.2.1 baseline

- Bounded tanh kernel.
- Plateau convergence loop.
- lambda, sigma, kappa constants.

### Added in v6.4.7

- Delta(H->SEAM) formalism.
- Hamiltonian cross-reference, not Hamiltonian-first naming.
- Gauge closed-loop descriptor.
- Fermionic exchange-parity and occupation descriptor.
- Operator-space descriptor.
- Full benchmark suite with seven PASS results.
- Strongest-candidate N-body numerical example.
