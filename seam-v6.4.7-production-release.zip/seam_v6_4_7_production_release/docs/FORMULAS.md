# SEAM v6.4.7 Formula Reconciliation

## Core SEAM kernel

```text
K_SEAM(x) = tanh(sigma * x + lambda)
```

Constants:

```text
lambda = -10.9147
sigma = 0.6206
kappa = 0.047055
```

## Plateau state

```text
S_(j+1) = clip(S_j + Delta_j * tanh(sigma * W(D) + lambda), -1, 1)
```

## Delta frame

```text
Delta(H->SEAM) = || O_SEAM* - O_Hamiltonian ||
```

This is not error against Hamiltonian ground truth. It is the delta between Hamiltonian-assumed correctness and SEAM-derived plateau correctness.

## Hamiltonian cross-reference

```text
H_cross = H_original + epsilon*kappa*sum(log(cosh(sigma*K_a(O(q,p))+lambda))) + C_SEAM
```

Hamiltonian notation is a projection layer only.
