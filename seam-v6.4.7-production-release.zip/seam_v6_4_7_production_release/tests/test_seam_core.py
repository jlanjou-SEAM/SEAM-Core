import unittest
from seam.core.engine import seam_kernel, process_descriptor
from seam.constraints.fermionic import constraint_score
from seam.benchmarks.suite import run_suite
from seam.benchmarks.nbody import run_nbody_delta_example

class TestSEAMCore(unittest.TestCase):
    def test_kernel_bounded(self):
        for x in [-100, -1, 0, 1, 100]:
            self.assertLessEqual(abs(seam_kernel(x)), 1.0)

    def test_process_descriptor(self):
        state = process_descriptor([0.8, 0.9, 1.0])
        self.assertGreaterEqual(state.composite, 0.0)
        self.assertLessEqual(state.composite, 1.0)

    def test_fermionic_constraint(self):
        score = constraint_score([0.8437331598232647, 0.9285050461187048, 0.9979423786840337, 0.96, 0.9764725])
        self.assertGreater(score, 0.55)

    def test_suite_passes(self):
        result = run_suite()
        self.assertEqual(result["aggregate"]["pass_count"], 7)
        self.assertEqual(result["aggregate"]["review_count"], 0)

    def test_nbody_delta(self):
        result = run_nbody_delta_example()
        self.assertGreater(result["delta_h_to_seam"]["norm"], 0.0)

if __name__ == "__main__":
    unittest.main()
