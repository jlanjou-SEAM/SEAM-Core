"""
Fermionic antisymmetric SEAM descriptor layer.

This is the v6.4.7 reconciliation of the FCI fix:
the missing variable is exchange parity / orbital occupation structure.
"""
import math

def _normalize(xs):
    n = len(xs)
    mean = sum(xs) / n if n else 0.0
    centered = [v - mean for v in xs]
    norm = math.sqrt(sum(v * v for v in centered)) or 1.0
    return [v / norm for v in centered]

def antisymmetric_descriptor(values):
    xs = _normalize([float(v) for v in values])
    n = len(xs)
    if n == 0:
        return [0.0]

    desc = []
    for i, x in enumerate(xs):
        exchange_parity = -1.0 if i % 2 else 1.0
        spin_channel = -0.5 if i % 2 else 0.5
        desc.append(math.tanh(exchange_parity * (i + 1) * x))
        desc.append(math.tanh(spin_channel * x))

    for i in range(n):
        for j in range(i + 1, n):
            parity = -1.0 if ((i + j) % 2) else 1.0
            wedge = parity * (xs[i] - xs[j]) * (i + 1) * (j + 1) / max(1, n * n)
            desc.append(math.tanh(4.0 * wedge))

    sorted_abs = sorted(abs(x) for x in xs)
    for i in range(len(sorted_abs) - 1):
        desc.append(math.tanh(12.0 * (sorted_abs[i + 1] - sorted_abs[i])))

    return desc or [0.0]

def constraint_score(values):
    d = antisymmetric_descriptor(values)
    magnitude = sum(abs(v) for v in d) / len(d)
    energy = math.sqrt(sum(v * v for v in d) / len(d))
    positives = sum(1 for v in d if v >= 0)
    negatives = len(d) - positives
    sign_balance = 1.0 - abs(positives - negatives) / len(d)
    score = 0.45 * math.tanh(3.0 * magnitude) + 0.35 * math.tanh(3.0 * energy) + 0.20 * sign_balance
    return max(0.0, min(1.0, score))
