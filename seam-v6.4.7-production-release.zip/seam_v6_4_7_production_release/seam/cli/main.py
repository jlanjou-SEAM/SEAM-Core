"""SEAM v6.4.7 CLI."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from seam.benchmarks.suite import run_suite
from seam.benchmarks.nbody import run_nbody_delta_example

def _write(payload: dict, out: str | None):
    if out:
        p = Path(out)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(payload, indent=2))
    print(json.dumps(payload, indent=2))

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="seam", description="SEAM v6.4.7 production CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    suite = sub.add_parser("run-suite", help="Run full SEAM invariant benchmark suite")
    suite.add_argument("--out", default="results/seam_v6_4_7_suite.json")

    nbody = sub.add_parser("nbody-example", help="Run strongest-candidate Delta(H->SEAM) example")
    nbody.add_argument("--out", default="results/seam_v6_4_7_nbody_delta.json")

    args = parser.parse_args(argv)
    if args.cmd == "run-suite":
        _write(run_suite(), args.out)
        return 0
    if args.cmd == "nbody-example":
        _write(run_nbody_delta_example(), args.out)
        return 0
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
