"""SEAM v6.4.7 production release."""
__version__ = "v6.4.7"
