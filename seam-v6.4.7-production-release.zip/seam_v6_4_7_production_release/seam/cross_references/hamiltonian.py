"""
Hamiltonian cross-reference layer.

This module projects SEAM descriptors into Hamiltonian notation.
It does not make Hamiltonian output ground truth.
"""
import math
from seam.core.constants import LAMBDA, SIGMA, KAPPA

def log_cosh_potential(x: float) -> float:
    z = SIGMA * x + LAMBDA
    return abs(z) + math.log1p(math.exp(-2 * abs(z))) - math.log(2)

def project_state(seam_state: dict | object, original_label: str = "H_original") -> dict:
    if hasattr(seam_state, "to_dict"):
        seam_state = seam_state.to_dict()
    k = float(seam_state["phase_drive"])
    h_seam = KAPPA * log_cosh_potential(k)
    force_norm = abs(math.tanh(SIGMA * k + LAMBDA)) * SIGMA * KAPPA
    stationarity = max(0.0, min(1.0, 1.0 - seam_state["plateau_residual"] - 0.1 * force_norm))
    return {
        "projection_type": "Hamiltonian cross-reference",
        "ground_truth_status": "not assumed",
        "H_original": original_label,
        "H_projection": "H_cross = H_original + epsilon*kappa*sum(log(cosh(sigma*K_a(O(q,p))+lambda))) + C_SEAM",
        "H_SEAM_scalar": h_seam,
        "bounded_force_norm": force_norm,
        "descriptor_stationarity": stationarity,
    }
