"""
SEAM v6.4.7 core engine.

SEAM is the primary framework.
Hamiltonian notation is a cross-reference/projection layer, not the source of ground truth.

The core object is a plateau-stable invariant descriptor.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable, List, Dict, Any
import math

from .constants import VERSION, LAMBDA, SIGMA, KAPPA, DEFAULT_STEPS


@dataclass
class SEAMState:
    version: str
    descriptor_vector: List[float]
    weighted_descriptor: float
    phase_drive: float
    activation: float
    plateau_state: float
    plateau_residual: float
    invariance: float
    recoverability: float
    stability: float
    compression: float
    composite: float
    constraint_kind: str | None = None
    constraint_score: float = 1.0
    constraint_descriptor_size: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def clamp(x: float, lo: float = -1.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def seam_kernel(x: float, *, sigma: float = SIGMA, lam: float = LAMBDA) -> float:
    """Bounded SEAM actuation kernel."""
    return math.tanh(sigma * x + lam)


def weighted_descriptor(values: Iterable[float]) -> float:
    xs = [float(v) for v in values]
    if not xs:
        raise ValueError("descriptor vector must be non-empty")
    return sum((i + 1) * v for i, v in enumerate(xs)) / len(xs)


def phase_drive_from_descriptor(values: Iterable[float], constraint_score: float = 1.0) -> float:
    w = weighted_descriptor(values)
    return 20.0 * KAPPA * w + 18.0 + 0.7 * constraint_score


def plateau_convergence(phase_drive: float, steps: int = DEFAULT_STEPS) -> tuple[float, float]:
    """Return (plateau_state, final_residual)."""
    s = 0.0
    residual = 0.0
    activation = seam_kernel(phase_drive)
    for j in range(steps):
        step = (1.0 / (j + 2)) * activation
        s_next = clamp(s + step * (1.0 - abs(s)))
        residual = abs(s_next - s)
        s = s_next
    return s, residual


def process_descriptor(
    descriptor_vector: Iterable[float],
    *,
    difficulty: float = 0.9,
    constraint_kind: str | None = None,
    constraint_score: float = 1.0,
    constraint_descriptor_size: int = 0,
    steps: int = DEFAULT_STEPS,
) -> SEAMState:
    """Process a descriptor vector into a SEAM v6.4.7 plateau state."""
    d = [float(v) for v in descriptor_vector]
    w = weighted_descriptor(d)
    drive = phase_drive_from_descriptor(d, constraint_score)
    activation = seam_kernel(drive)
    plateau, residual = plateau_convergence(drive, steps=steps)

    constraint_bonus = (constraint_score - 0.5) if constraint_kind else 0.0

    invariance = max(0.0, min(1.0, 1.0 - residual))
    recoverability = max(0.0, min(1.0, 0.70 + 0.26 * abs(plateau) - 0.04 * difficulty + 0.05 * constraint_bonus))
    stability = max(0.0, min(1.0, 1.0 / (1.0 + 4.0 * residual + 0.15 * difficulty) + 0.04 * constraint_bonus))
    compression = max(0.0, min(1.0, 1.0 - 0.42 * difficulty + 0.25 * abs(plateau) + 0.04 * constraint_bonus))
    composite = 0.30 * invariance + 0.30 * recoverability + 0.25 * stability + 0.15 * compression

    return SEAMState(
        version=VERSION,
        descriptor_vector=d,
        weighted_descriptor=w,
        phase_drive=drive,
        activation=activation,
        plateau_state=plateau,
        plateau_residual=residual,
        invariance=invariance,
        recoverability=recoverability,
        stability=stability,
        compression=compression,
        composite=composite,
        constraint_kind=constraint_kind,
        constraint_score=constraint_score,
        constraint_descriptor_size=constraint_descriptor_size,
    )
