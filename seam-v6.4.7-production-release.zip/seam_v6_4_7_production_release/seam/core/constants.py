"""
SEAM v6.4.7 constants.

Baseline reconciliation:
- lambda, sigma, and kappa originate from the v6.2.1/v6.1.x plateau lineage.
- v6.4.7 preserves those anchors but adds delta-frame analysis and domain constraints.
"""

VERSION = "v6.4.7"

LAMBDA = -10.9147
SIGMA = 0.6206
KAPPA = 0.047055

DEFAULT_STEPS = 10
