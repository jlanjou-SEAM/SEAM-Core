SEAM Epistemic Acquisition Runtime v2.3

Change list:
------------
1. Timeout reduced:
   6 seconds -> 2 seconds

2. Curated data routes added as first-class endpoint arrays:
   - curated
   - official

3. Production routes retained:
   - primary_raw       -> raw/
   - secondary_curated -> decoded/

4. Explicit endpoint/source override supported:
   "epistemic_layer": "raw" | "decoded" | "curated"

5. Console now prints task route and layer counts before fetching.

Install:
--------
Replace:
C:\CleanRoom\continuum_dual_acquisition_runtime.py

Run:
----
python continuum_dual_acquisition_runtime.py

Expected:
---------
Sources configured: 40
Fetch tasks: around 55 or higher if curated/official endpoints exist
Timeout: 2s
