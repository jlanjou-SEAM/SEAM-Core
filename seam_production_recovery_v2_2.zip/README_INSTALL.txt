SEAM production recovery package v2.2

This package restores the real 40-source acquisition configuration and replaces the broken 3-source demo config.

Install these files into C:\CleanRoom:
- config/dual_acquisition_sources.json
- continuum_dual_acquisition_runtime.py
- seam_unified_48h_field.py
- continuum_retention_manager.py

Behavior:
- primary_raw endpoints -> raw/
- secondary_curated endpoints -> decoded/ by default
- explicit epistemic_layer=curated -> curated/
- unified field reads only raw/ + decoded/
- unified output goes to combined/
- curated is preserved for validation only

Validation:
python continuum_dual_acquisition_runtime.py

Expected:
Sources configured: 40
Fetch tasks: about 55
Successful fetches: about 50+

Then:
python seam_unified_48h_field.py

Expected output:
combined/seam_unified_recursive_field_48h.json
