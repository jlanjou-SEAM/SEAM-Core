SEAM Epistemic Acquisition Runtime v2.1

This fixes the bad v2.0 acquisition stub.

v2.1 is a real downloader and restores the working behavior:
- loads config/dual_acquisition_sources.json
- creates endpoint fetch tasks
- downloads all enabled sources
- writes payloads to disk
- writes logs/acquisition_log.jsonl
- writes state/source_health.json

New epistemic routing:
- raw/      = live unresolved observations
- decoded/  = interpreted unofficial evidence
- curated/  = official/retrospective validation

Compatibility:
- Existing primary_raw endpoints default to raw/
- Existing secondary_curated endpoints default to decoded/
- Official/NOAA/NWS/SPC/report-like sources route to curated/
- New configs may explicitly set "epistemic_layer"

Install:
Replace:
    C:\CleanRoom\continuum_dual_acquisition_runtime.py

Run:
    python continuum_dual_acquisition_runtime.py

Expected:
    Sources configured: ~40
    Fetch tasks: ~55
    Successful fetches: ~50+
