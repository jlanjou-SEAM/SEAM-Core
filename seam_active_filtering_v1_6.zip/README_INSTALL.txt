SEAM Active Filtering + Manifold Lock Fix v1.6

Fixes:
- Preserves SEAM manifold lock values:
  0.91 -> 91
  91   -> 91
  100  -> 100

- Active dashboard window is now 12 hours.

- Adds filtering diagnostics to data/latest.json:
  filtered_missing_time
  filtered_future
  filtered_old
  filtered_threshold
  dashboard_events

Install:
Replace C:\CleanRoom\continuum_cross_stream_reconcile.py

Run:
python continuum_cross_stream_reconcile.py

Publish:
git add -A
git commit -m "Fix manifold lock normalization and 12 hour active filter"
git push origin main
