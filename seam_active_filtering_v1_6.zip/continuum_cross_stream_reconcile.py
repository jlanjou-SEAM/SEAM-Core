
from __future__ import annotations

import json
import math
from datetime import datetime, timezone, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent

LIVE_EVENT_PATH = ROOT / "reports" / "live_event_state.json"
TRACK_PATH = ROOT / "reports" / "persistent_field_tracks_current.json"

REPORT_OUTPUT = ROOT / "reports" / "cross_stream_manifolds_current.json"
DASHBOARD_OUTPUT = ROOT / "data" / "latest.json"

ACTIVE_WINDOW_HOURS = 12
FUTURE_TOLERANCE_MINUTES = 10
MANIFOLD_THRESHOLD_PERCENT = 70


def load_json(path: Path):
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        print(f"[LOAD FAILED] {path}: {exc}")
        return {}


def parse_time(value):
    if not value:
        return None

    if isinstance(value, (int, float)):
        try:
            if value > 10_000_000_000:
                return datetime.fromtimestamp(value / 1000, tz=timezone.utc)
            return datetime.fromtimestamp(value, tz=timezone.utc)
        except Exception:
            return None

    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except Exception:
        return None


def event_times(event):
    fields = [
        "last_seen_utc",
        "official_registration_utc",
        "forecast_lock_utc",
        "first_seen_utc",
        "timestamp_utc",
        "created_utc",
    ]

    times = []
    for field in fields:
        parsed = parse_time(event.get(field))
        if parsed:
            times.append(parsed)

    return times


def normalize_manifold_lock(value):
    """
    Preserve SEAM authoritative lock values.

    0.91 -> 91
    91   -> 91
    100  -> 100
    """

    try:
        raw = float(value)
    except Exception:
        return 0

    if math.isnan(raw) or math.isinf(raw) or raw < 0:
        return 0

    if raw <= 1.0:
        return round(raw * 100)

    if raw <= 100.0:
        return round(raw)

    return 100


def authoritative_manifold_lock(event):
    for key in [
        "manifold_lock",
        "manifold_lock_percentage",
        "lock_percentage",
        "seam_phi",
        "forecast_confidence",
    ]:
        if key in event and event.get(key) is not None:
            return normalize_manifold_lock(event.get(key))
    return 0


def classify_sources(sources):
    live = []
    delayed = []
    for source in sources or []:
        normalized = str(source).replace("\\", "/").lower()
        if "/raw/" in normalized:
            live.append(source)
        elif "/curated/" in normalized:
            delayed.append(source)
    return live, delayed


def haversine_miles(lat1, lon1, lat2, lon2):
    radius_miles = 3958.8
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = (
        math.sin(dphi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    )

    return 2 * radius_miles * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def nearest_track(event, tracks):
    lat = event.get("latitude")
    lon = event.get("longitude")

    if lat is None or lon is None:
        return None

    best = None
    best_distance = 999999

    for track in tracks:
        tlat = track.get("current_latitude")
        tlon = track.get("current_longitude")

        if tlat is None or tlon is None:
            continue

        distance = haversine_miles(float(lat), float(lon), float(tlat), float(tlon))

        if distance < best_distance:
            best_distance = distance
            best = track

    return best


def track_viability(track):
    if not track:
        return 0

    count = int(track.get("event_count", 0))
    velocity = track.get("velocity_vector", {})

    delta_lat = abs(float(velocity.get("delta_latitude", 0.0)))
    delta_lon = abs(float(velocity.get("delta_longitude", 0.0)))

    motion_penalty = min(1.0, (delta_lat + delta_lon) * 5.0)
    base = min(1.0, math.log10(count + 1) / 2.0)

    return round(max(0.0, base - (motion_penalty * 0.35)) * 100)


def region_label(event):
    regime = str(event.get("primary_regime", "event")).upper()
    lat = float(event.get("latitude", 0.0))
    lon = float(event.get("longitude", 0.0))
    return f"{regime} {lat:.2f}, {lon:.2f}"


def build_hypothesis(event, live_count, delayed_count):
    regime = str(event.get("primary_regime", "event")).upper()
    verification = event.get("verification_state", "UNVERIFIED")
    lead_time = int(event.get("lead_time_seconds", 0))
    return (
        f"{regime} target {verification.lower()} | "
        f"lead {lead_time}s | "
        f"live {live_count} / delayed {delayed_count}"
    )


def reconcile(events, tracks):
    now = datetime.now(timezone.utc)

    dashboard_events = []
    manifolds = []

    stats = {
        "input_events": len(events),
        "filtered_missing_time": 0,
        "filtered_future": 0,
        "filtered_old": 0,
        "filtered_threshold": 0,
        "dashboard_events": 0,
    }

    for index, event in enumerate(events):
        times = event_times(event)

        if not times:
            stats["filtered_missing_time"] += 1
            continue

        newest = max(times)

        if newest > now + timedelta(minutes=FUTURE_TOLERANCE_MINUTES):
            stats["filtered_future"] += 1
            continue

        if (now - newest) > timedelta(hours=ACTIVE_WINDOW_HOURS):
            stats["filtered_old"] += 1
            continue

        likelihood = authoritative_manifold_lock(event)

        if likelihood < MANIFOLD_THRESHOLD_PERCENT:
            stats["filtered_threshold"] += 1
            continue

        lat = event.get("latitude")
        lon = event.get("longitude")

        if lat is None or lon is None:
            continue

        live_sources, delayed_sources = classify_sources(event.get("sources", []))
        track = nearest_track(event, tracks)
        persistence = track_viability(track)

        trajectory = "stable" if persistence > 70 else "tracking" if persistence > 40 else "volatile"

        dashboard_event = {
            "event_id": event.get("event_id", f"EVT-{index:06d}"),
            "region": region_label(event),
            "hypothesis": build_hypothesis(event, len(live_sources), len(delayed_sources)),
            "realization_probability": likelihood,
            "persistence": persistence,
            "observation_count": event.get("observation_count", 0),
            "lat": lat,
            "lon": lon,
            "state": event.get("lock_state", "MONITOR"),
            "trajectory": trajectory,
            "primary_regime": event.get("primary_regime", "unknown"),
            "verification_state": event.get("verification_state", "UNVERIFIED"),
            "lead_time_seconds": int(event.get("lead_time_seconds", 0)),
            "live_source_count": len(live_sources),
            "delayed_source_count": len(delayed_sources),
            "active_timestamp_utc": newest.isoformat(),
            "sources": event.get("sources", []),
            "evidence": [
                f"verification_{event.get('verification_state', 'unknown').lower()}",
                f"live_sources_{len(live_sources)}",
                f"delayed_sources_{len(delayed_sources)}",
            ],
            "contradictions": [],
        }

        dashboard_events.append(dashboard_event)

        manifolds.append(
            {
                "manifold_id": f"MANI-{index:05d}",
                "event_id": dashboard_event["event_id"],
                "likelihood": likelihood,
                "persistence": persistence,
                "active_timestamp_utc": newest.isoformat(),
            }
        )

    dashboard_events = sorted(
        dashboard_events,
        key=lambda x: (
            x["realization_probability"],
            x["persistence"],
            x["observation_count"],
        ),
        reverse=True,
    )

    stats["dashboard_events"] = len(dashboard_events)
    return manifolds, dashboard_events, stats


def export_manifolds(manifolds, stats):
    REPORT_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "active_window_hours": ACTIVE_WINDOW_HOURS,
        "future_tolerance_minutes": FUTURE_TOLERANCE_MINUTES,
        "manifold_threshold_percent": MANIFOLD_THRESHOLD_PERCENT,
        "stats": stats,
        "manifold_count": len(manifolds),
        "manifolds": manifolds,
    }
    with open(REPORT_OUTPUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def export_dashboard(events, stats):
    DASHBOARD_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "active_window_hours": ACTIVE_WINDOW_HOURS,
        "future_tolerance_minutes": FUTURE_TOLERANCE_MINUTES,
        "manifold_threshold_percent": MANIFOLD_THRESHOLD_PERCENT,
        "stats": stats,
        "event_count": len(events),
        "active_events": events,
    }
    with open(DASHBOARD_OUTPUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def main():
    live_payload = load_json(LIVE_EVENT_PATH)
    track_payload = load_json(TRACK_PATH)

    events = live_payload.get("events", [])
    tracks = track_payload.get("tracks", [])

    print()
    print("=== SEAM CROSS-STREAM RECONCILIATION v1.6 ===")
    print()
    print(f"Input events: {len(events)}")
    print(f"Persistent tracks: {len(tracks)}")
    print(f"Active window: {ACTIVE_WINDOW_HOURS} hours")
    print(f"Manifold threshold: {MANIFOLD_THRESHOLD_PERCENT}%")

    manifolds, dashboard_events, stats = reconcile(events, tracks)

    export_manifolds(manifolds, stats)
    export_dashboard(dashboard_events, stats)

    print()
    for key, value in stats.items():
        print(f"{key}: {value}")
    print(f"Dashboard export: {DASHBOARD_OUTPUT}")
    print()


if __name__ == "__main__":
    main()
