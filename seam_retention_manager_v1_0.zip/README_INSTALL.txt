SEAM Retention Manager v1.0

Purpose:
--------
Prevent uncontrolled growth of:
- raw/
- curated/
- analysis/

while preserving:
- long-term archives
- recursive manifold integrity

Behavior:
---------
Files older than 48 hours are moved to:

archive/raw/
archive/curated/
archive/analysis/

Protected files remain in place:
- latest.json
- live_event_state.json
- manifold outputs
- unified 48h field

Why This Matters:
-----------------
Without retention:
- recursive manifolds become artificially reinforced forever
- stale confirmations contaminate active synthesis
- runtime performance degrades
- Git history explodes

Install:
--------
Copy:
continuum_retention_manager.py

to:
C:\CleanRoom

Run:
----
python continuum_retention_manager.py

Recommended Pipeline Position:
------------------------------
acquisition
    ↓
unified 48h field
    ↓
SEAM synthesis
    ↓
dashboard export
    ↓
RETENTION MANAGEMENT

Batch Addition:
---------------
python continuum_retention_manager.py
