"""
continuum_retention_manager.py
SEAM Retention Manager
Version: 1.0

Purpose:
--------
Maintain operational integrity of the SEAM runtime by enforcing:
- rolling 48-hour hot datasets
- archival migration
- operational working set limits

Hot Directories:
----------------
raw/
curated/
analysis/

Cold Archive:
-------------
archive/raw/
archive/curated/
archive/analysis/

Retention:
----------
48 hours

Behavior:
---------
- moves older files to archive
- preserves directory structure
- skips current public outputs
- preserves active dashboard exports
"""

from __future__ import annotations

import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
import re


ROOT = Path(__file__).resolve().parent

HOT_DIRS = [
    ROOT / "raw",
    ROOT / "curated",
    ROOT / "analysis"
]

ARCHIVE_ROOT = ROOT / "archive"

RETENTION_HOURS = 48

PROTECTED_FILENAMES = {
    "latest.json",
    "live_event_state.json",
    "cross_stream_manifolds_current.json",
    "canonical_spacetime_events_current.json",
    "persistent_field_tracks_current.json",
    "seam_unified_recursive_field_48h.json",
}

VALID_SUFFIXES = {
    ".json",
    ".geojson",
    ".jsonl",
    ".txt",
    ".csv",
    ".xml",
    ".payload"
}


# ============================================================
# TIME HELPERS
# ============================================================

def utc_now():
    return datetime.now(timezone.utc)


def parse_datetime(text: str) -> Optional[datetime]:

    if not text:
        return None

    try:
        parsed = datetime.fromisoformat(
            text.replace("Z", "+00:00")
        )

        if parsed.tzinfo is None:
            parsed = parsed.replace(
                tzinfo=timezone.utc
            )

        return parsed.astimezone(timezone.utc)

    except Exception:
        return None


def infer_time_from_path(path: Path) -> Optional[datetime]:

    # Match YYYY-MM-DD
    match = re.search(
        r"(20\d{2}-\d{2}-\d{2})",
        str(path)
    )

    if match:
        try:
            return datetime.fromisoformat(
                match.group(1)
            ).replace(tzinfo=timezone.utc)
        except Exception:
            pass

    # Match HHMMSS filename prefix
    match = re.search(
        r"(\d{6})_",
        path.name
    )

    if match:
        hhmmss = match.group(1)

        try:
            today = utc_now().date()

            return datetime(
                today.year,
                today.month,
                today.day,
                int(hhmmss[0:2]),
                int(hhmmss[2:4]),
                int(hhmmss[4:6]),
                tzinfo=timezone.utc
            )

        except Exception:
            pass

    return None


def file_age_hours(path: Path) -> float:

    inferred = infer_time_from_path(path)

    if inferred:
        delta = utc_now() - inferred
        return delta.total_seconds() / 3600

    try:
        modified = datetime.fromtimestamp(
            path.stat().st_mtime,
            tz=timezone.utc
        )

        delta = utc_now() - modified

        return delta.total_seconds() / 3600

    except Exception:
        return 0


# ============================================================
# ARCHIVAL
# ============================================================

def should_skip(path: Path) -> bool:

    if path.name in PROTECTED_FILENAMES:
        return True

    if path.suffix.lower() not in VALID_SUFFIXES:
        return True

    normalized = str(path).replace("\\", "/").lower()

    if "/archive/" in normalized:
        return True

    return False


def archive_destination(path: Path) -> Path:

    relative = path.relative_to(ROOT)

    return ARCHIVE_ROOT / relative


def ensure_parent(path: Path):

    path.parent.mkdir(
        parents=True,
        exist_ok=True
    )


def move_to_archive(path: Path):

    destination = archive_destination(path)

    ensure_parent(destination)

    shutil.move(
        str(path),
        str(destination)
    )

    return destination


# ============================================================
# RETENTION EXECUTION
# ============================================================

def retention_pass():

    cutoff_hours = RETENTION_HOURS

    moved = []
    skipped = []
    retained = []

    for root in HOT_DIRS:

        if not root.exists():
            continue

        for path in root.rglob("*"):

            if not path.is_file():
                continue

            if should_skip(path):
                skipped.append(str(path))
                continue

            age = file_age_hours(path)

            if age <= cutoff_hours:
                retained.append(str(path))
                continue

            try:

                destination = move_to_archive(path)

                moved.append({
                    "source": str(path),
                    "destination": str(destination),
                    "age_hours": round(age, 2)
                })

            except Exception as exc:

                skipped.append(
                    f"{path} :: {exc}"
                )

    return {
        "generated_utc": utc_now().isoformat(),
        "retention_hours": RETENTION_HOURS,
        "moved_count": len(moved),
        "retained_count": len(retained),
        "skipped_count": len(skipped),
        "moved": moved[:200],
        "retained_sample": retained[:50],
        "skipped_sample": skipped[:50]
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=== SEAM RETENTION MANAGER v1.0 ===")
    print()

    result = retention_pass()

    print(f"Retention window : {RETENTION_HOURS}h")
    print(f"Moved to archive : {result['moved_count']}")
    print(f"Retained hot set : {result['retained_count']}")
    print(f"Skipped/protected: {result['skipped_count']}")
    print()

    if result["moved"]:
        print("Sample archived files:")
        print()

        for item in result["moved"][:10]:
            print(
                f"  {item['age_hours']}h :: "
                f"{item['source']}"
            )

        print()

    print(f"Archive root: {ARCHIVE_ROOT}")
    print()


if __name__ == "__main__":
    main()
