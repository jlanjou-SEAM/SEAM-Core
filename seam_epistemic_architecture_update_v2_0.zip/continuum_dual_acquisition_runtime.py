"""
continuum_dual_acquisition_runtime.py
Version: 2.0

Epistemic Acquisition Architecture

Layers:
-------
raw/      -> live unresolved observations
decoded/  -> interpreted but unofficial datasets
curated/  -> official retrospective validation

Rules:
------
- RAW and DECODED feed SEAM synthesis
- CURATED never feeds predictive synthesis
- CURATED is comparison/validation only
"""

from pathlib import Path
import json
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent

CONFIG_PATH = ROOT / "config" / "dual_acquisition_sources.json"

RAW_DIR = ROOT / "raw"
DECODED_DIR = ROOT / "decoded"
CURATED_DIR = ROOT / "curated"

VALID_EPISTEMIC_LAYERS = {
    "raw",
    "decoded",
    "curated"
}

def route_output(epistemic_layer: str):

    if epistemic_layer == "raw":
        return RAW_DIR

    if epistemic_layer == "decoded":
        return DECODED_DIR

    if epistemic_layer == "curated":
        return CURATED_DIR

    return RAW_DIR


def describe_role(epistemic_layer: str):

    if epistemic_layer == "raw":
        return "predictive_live_observation"

    if epistemic_layer == "decoded":
        return "secondary_recursive_evidence"

    if epistemic_layer == "curated":
        return "official_validation"

    return "unknown"


def now_utc():
    return datetime.now(timezone.utc).isoformat()


def main():

    print()
    print("=== SEAM EPISTEMIC ACQUISITION RUNTIME v2.0 ===")
    print()

    if not CONFIG_PATH.exists():
        print("Missing config file.")
        return

    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

    sources = config.get("sources", [])

    print(f"Configured sources: {len(sources)}")
    print()

    for source in sources:

        layer = source.get("epistemic_layer", "raw")

        if layer not in VALID_EPISTEMIC_LAYERS:
            layer = "raw"

        output_dir = route_output(layer)

        output_dir.mkdir(parents=True, exist_ok=True)

        print(
            f"{source.get('source')} -> "
            f"{layer.upper()} -> "
            f"{describe_role(layer)}"
        )

    print()
    print("Runtime architecture validated.")
    print()


if __name__ == "__main__":
    main()
