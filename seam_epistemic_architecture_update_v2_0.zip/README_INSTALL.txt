SEAM Epistemic Architecture Update v2.0

Core Architectural Change:
--------------------------
Acquisition, ingestion, synthesis, and retention
are now organized around epistemic state.

Layers:
-------
raw/
    live unresolved observational space

decoded/
    interpreted but unofficial evidence space

curated/
    official retrospective validation space

combined/
    SEAM-native recursive observation field

Critical Rule:
--------------
ONLY:
    raw/
    decoded/

feed predictive synthesis.

curated/
is comparison and validation only.

Updated Files:
--------------
continuum_dual_acquisition_runtime.py
seam_unified_48h_field.py
continuum_retention_manager.py
config/dual_acquisition_sources.json
BAT_PIPELINE_PATCH.txt

Pipeline:
---------
raw + decoded
    ↓
combined
    ↓
SEAM recursive manifold synthesis
    ↓
curated comparison
    ↓
dashboard export
    ↓
retention/archive

Install:
--------
Replace existing runtime files.

Create directory:
    combined/

Run:
----
python seam_unified_48h_field.py
