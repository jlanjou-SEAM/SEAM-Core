# SEAM v6.4.9 Claims and Limitations

## Supported claims

- SEAM maps observable descriptors into bounded plateau-stable invariant representations.
- Delta(H->SEAM) measures framework disagreement, not correctness by itself.
- This release includes numerical baseline comparisons and sensitivity analysis.

## Unsupported claims

- SEAM replaces Hamiltonian mechanics.
- SEAM proves Hamiltonian calculations are wrong.
- SEAM predicts physical systems more accurately without external validation.

## Open validation needs

- Real experimental data.
- Domain-specific baselines for QCD, FCI, SYK, plasma, and turbulence.
- Systematic coefficient optimization or derivation.
