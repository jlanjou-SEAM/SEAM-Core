# SEAM v6.4.9 Validation Release

SEAM is the primary descriptor framework. Hamiltonian notation is a cross-reference layer only.

## Purpose

This release includes:

- external numerical N-body baseline generation
- comparison against RK4, Velocity-Verlet, and Leapfrog
- sensitivity analysis for descriptors, constants, and weights
- cleaned claim boundaries

## Commands

```bash
python -m seam.cli run-suite
python -m seam.cli validate-nbody
python -m seam.cli sensitivity
python -m seam.cli nbody-example
```

## Claim boundary

SEAM v6.4.9 is a validation-oriented descriptor framework. It does not claim superiority over Hamiltonian mechanics or other methods without external validation.
