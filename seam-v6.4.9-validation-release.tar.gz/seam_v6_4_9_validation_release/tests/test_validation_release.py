import unittest
from seam.benchmarks.suite import run_suite
from seam.validation.seam_vs_integrators import run_validation
from seam.validation.sensitivity_analysis import run_sensitivity
from seam.constraints.fermionic import constraint_score
class TestValidationRelease(unittest.TestCase):
    def test_suite(self):
        r=run_suite()
        self.assertEqual(r["aggregate"]["pass_count"],7)
    def test_fci_constraint(self):
        self.assertGreater(constraint_score([0.84,0.93,0.99,0.96,0.976]),0.55)
    def test_nbody_validation(self):
        r=run_validation()
        self.assertEqual(len(r["baselines"]),3)
        self.assertTrue(all(b["max_energy_error"] >= 0 for b in r["baselines"]))
    def test_sensitivity(self):
        r=run_sensitivity(samples=20)
        self.assertGreater(r["composite_mean"],0)
        self.assertLess(r["composite_std"],0.1)
if __name__=="__main__":
    unittest.main()
