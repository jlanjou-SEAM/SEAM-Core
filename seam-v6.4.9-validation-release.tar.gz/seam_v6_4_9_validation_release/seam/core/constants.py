"""SEAM v6.4.9 constants and coefficient declarations."""
VERSION = "v6.4.9"
BASELINE_VERSION = "v6.2.1"

# v6.2.1/v6.1.x plateau lineage anchors.
LAMBDA = -10.9147
SIGMA = 0.6206
KAPPA = 0.047055
DEFAULT_STEPS = 10

# v6.4.9 validation policy:
# These are model coefficients, not physical constants.
COEFFICIENT_STATUS = {
    "LAMBDA": "baseline-inherited",
    "SIGMA": "baseline-inherited",
    "KAPPA": "baseline-inherited",
    "metric_weights": "provisional; sensitivity-tested",
    "constraint_weights": "provisional; sensitivity-tested"
}
