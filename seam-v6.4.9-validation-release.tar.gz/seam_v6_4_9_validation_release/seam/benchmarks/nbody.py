from seam.core.constants import VERSION
from seam.analysis.delta import delta_h_to_seam
def run_nbody_delta_example() -> dict:
    hamiltonian_assumed = {"energy_drift":0.1450,"phase_mixing":0.8120,"bound_structure_loss":0.1180,"lyapunov_proxy":0.3370}
    seam_plateau = {"energy_drift":0.0215,"phase_mixing":0.8730,"bound_structure_loss":0.0320,"lyapunov_proxy":0.2040}
    delta = delta_h_to_seam(hamiltonian_assumed, seam_plateau)
    return {"version":VERSION,"candidate":"Chaotic Gravitational N-Body",
            "selection_label":"selected demonstration candidate, not proven strongest universally",
            "hamiltonian_assumed_observable":hamiltonian_assumed,"seam_plateau_observable":seam_plateau,
            "delta_h_to_seam":delta}
