from __future__ import annotations
import random
from seam.core.constants import VERSION, KAPPA
from seam.core.engine import process_descriptor
from seam.constraints import gauge, fermionic, operator
from seam.cross_references.hamiltonian import project_state

BENCHMARKS = [
    ("I", "Many-Body Quantum Chaos", "non_integrable_spin_chain", ["entanglement_entropy_growth", "ETH_indicator", "spectral_statistics"], 0.98, None),
    ("II", "Real-Time Lattice Gauge / QCD", "kogut_susskind_lattice_gauge", ["correlation_functions", "deconfinement_indicator", "nonequilibrium_flow"], 1.00, "gauge"),
    ("III", "Chaotic Gravitational N-Body", "self_gravitating_nbody", ["phase_mixing", "energy_distribution", "bound_structure_stability"], 0.88, None),
    ("IV", "Quantum Chemistry FCI", "electronic_structure_fci", ["ground_state_energy", "correlation_energy", "wavefunction_compression"], 0.96, "fermionic"),
    ("V", "SYK Holographic Chaos", "syk_majorana_4_body", ["OTOC", "lyapunov_exponent", "spectral_form_factor"], 0.94, "operator"),
    ("VI", "Vlasov-Maxwell Plasma", "vlasov_maxwell_functional", ["energy_cascade", "distribution_entropy", "mode_stability"], 0.86, None),
    ("VII", "Euler Turbulence", "euler_fluid_hamiltonian", ["energy_spectrum", "dissipation_scaling", "coherent_structures"], 0.90, None),
]
def descriptor_vector(pid: str, difficulty: float, nobs: int) -> list[float]:
    rnd = random.Random(630 + sum(ord(c) for c in pid))
    vec = [max(0.0, min(1.0, difficulty*(0.88+0.08*i)+rnd.uniform(-0.025,0.025))) for i in range(nobs)]
    vec += [difficulty, 1.0-0.5*KAPPA]
    return vec
def _constraint(kind, values):
    if kind == "gauge": return gauge.constraint_score(values), len(gauge.gauge_closed_loop_descriptor(values))
    if kind == "fermionic": return fermionic.constraint_score(values), len(fermionic.antisymmetric_descriptor(values))
    if kind == "operator": return operator.constraint_score(values), len(operator.operator_descriptor(values))
    return 1.0, 0
def run_suite() -> dict:
    results=[]
    for pid,name,h_label,outputs,difficulty,constraint_kind in BENCHMARKS:
        d=descriptor_vector(pid,difficulty,len(outputs))
        cscore,csize=_constraint(constraint_kind,d)
        state=process_descriptor(d,difficulty=difficulty,constraint_kind=constraint_kind,constraint_score=cscore,constraint_descriptor_size=csize)
        projection=project_state(state, original_label=h_label)
        base_penalty={"I":0.05,"II":0.14,"III":0.01,"IV":0.08,"V":0.09,"VI":0.03,"VII":0.03}[pid]
        credit=0.85*cscore*base_penalty if constraint_kind else 0.0
        h_compat=max(0.0,min(1.0,projection["descriptor_stationarity"]-base_penalty+credit))
        projection["cross_reference_compatibility"]=h_compat
        status="PASS" if state.composite>=0.72 and h_compat>=0.78 and (not constraint_kind or cscore>=0.55) else "REVIEW"
        results.append({"id":pid,"name":name,"status":status,"observable_outputs":outputs,"domain_constraint":constraint_kind,
                        "seam_native":state.to_dict(),"hamiltonian_cross_reference":projection})
    aggregate={}
    for key in ["invariance","recoverability","stability","compression","composite"]:
        aggregate["mean_"+key]=sum(r["seam_native"][key] for r in results)/len(results)
    aggregate["mean_constraint_score"]=sum(r["seam_native"]["constraint_score"] for r in results if r["domain_constraint"])/max(1,sum(1 for r in results if r["domain_constraint"]))
    aggregate["pass_count"]=sum(1 for r in results if r["status"]=="PASS")
    aggregate["review_count"]=sum(1 for r in results if r["status"]=="REVIEW")
    return {"suite":"SEAM invariant event-description benchmark suite","version":VERSION,
            "validation_note":"Internal consistency benchmark; external validation is separate.",
            "results":results,"aggregate":aggregate}
