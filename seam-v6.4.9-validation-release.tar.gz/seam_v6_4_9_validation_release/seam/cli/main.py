import argparse,json
from pathlib import Path
from seam.benchmarks.suite import run_suite
from seam.benchmarks.nbody import run_nbody_delta_example
from seam.validation.seam_vs_integrators import run_validation
from seam.validation.sensitivity_analysis import run_sensitivity

def write(payload,out):
    if out:
        p=Path(out); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(payload,indent=2))
    print(json.dumps(payload,indent=2))

def main(argv=None):
    parser=argparse.ArgumentParser(prog="seam")
    sub=parser.add_subparsers(dest="cmd",required=True)
    a=sub.add_parser("run-suite"); a.add_argument("--out",default="results/seam_v6_4_9_suite.json")
    b=sub.add_parser("nbody-example"); b.add_argument("--out",default="results/seam_v6_4_9_nbody_delta.json")
    c=sub.add_parser("validate-nbody"); c.add_argument("--out",default="results/seam_v6_4_9_nbody_validation.json")
    d=sub.add_parser("sensitivity"); d.add_argument("--samples",type=int,default=200); d.add_argument("--out",default="results/seam_v6_4_9_sensitivity.json")
    args=parser.parse_args(argv)
    if args.cmd=="run-suite": write(run_suite(),args.out)
    elif args.cmd=="nbody-example": write(run_nbody_delta_example(),args.out)
    elif args.cmd=="validate-nbody": write(run_validation(),args.out)
    elif args.cmd=="sensitivity": write(run_sensitivity(args.samples),args.out)
    return 0
if __name__=="__main__":
    raise SystemExit(main())
