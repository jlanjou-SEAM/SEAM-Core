import math
def delta_h_to_seam(hamiltonian_observable: dict, seam_observable: dict) -> dict:
    keys = list(hamiltonian_observable.keys())
    missing = [k for k in keys if k not in seam_observable]
    if missing: raise ValueError(f"SEAM observable missing keys: {missing}")
    components = {k: float(seam_observable[k])-float(hamiltonian_observable[k]) for k in keys}
    norm = math.sqrt(sum(v*v for v in components.values()))
    base = math.sqrt(sum(float(hamiltonian_observable[k])**2 for k in keys))
    return {"components": components, "norm": norm, "relative": norm/base if base else 0.0,
            "interpretation": "Delta(H->SEAM), not error against Hamiltonian ground truth."}
