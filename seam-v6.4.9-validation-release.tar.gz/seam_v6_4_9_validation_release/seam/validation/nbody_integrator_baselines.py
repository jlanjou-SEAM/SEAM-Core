from __future__ import annotations
import math

G = 1.0
MASSES = [1.0, 0.001, 0.0012, 0.0015, 0.0018]
RADII = [0.0, 0.35, 0.55, 0.78, 1.05]

def initial_state():
    q=[]; v=[]
    for i,m in enumerate(MASSES):
        if i == 0:
            q.append([0.0,0.0]); v.append([0.0,0.0])
        else:
            r=RADII[i]; angle=0.7*i
            q.append([r*math.cos(angle), r*math.sin(angle)])
            speed=math.sqrt(G*MASSES[0]/r)
            v.append([-speed*math.sin(angle), speed*math.cos(angle)])
    # zero net momentum
    px=sum(MASSES[i]*v[i][0] for i in range(len(MASSES)))
    py=sum(MASSES[i]*v[i][1] for i in range(len(MASSES)))
    mt=sum(MASSES)
    for i in range(len(MASSES)):
        v[i][0]-=px/mt; v[i][1]-=py/mt
    return q, v

def acc(q):
    n=len(q); a=[[0.0,0.0] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i==j: continue
            dx=q[j][0]-q[i][0]; dy=q[j][1]-q[i][1]
            d2=dx*dx+dy*dy+1e-9
            d=math.sqrt(d2)
            c=G*MASSES[j]/(d2*d)
            a[i][0]+=c*dx; a[i][1]+=c*dy
    return a

def energy(q,v):
    ke=sum(0.5*MASSES[i]*(v[i][0]**2+v[i][1]**2) for i in range(len(q)))
    pe=0.0
    for i in range(len(q)):
        for j in range(i+1,len(q)):
            dx=q[i][0]-q[j][0]; dy=q[i][1]-q[j][1]
            pe -= G*MASSES[i]*MASSES[j]/math.sqrt(dx*dx+dy*dy+1e-12)
    return ke+pe

def min_pair_distance(q):
    m=1e99
    for i in range(len(q)):
        for j in range(i+1,len(q)):
            dx=q[i][0]-q[j][0]; dy=q[i][1]-q[j][1]
            m=min(m, math.sqrt(dx*dx+dy*dy))
    return m

def add_state(q,v,kq,kv,scale):
    return ([[q[i][0]+scale*kq[i][0], q[i][1]+scale*kq[i][1]] for i in range(len(q))],
            [[v[i][0]+scale*kv[i][0], v[i][1]+scale*kv[i][1]] for i in range(len(v))])

def step_rk4(q,v,dt):
    def rhs(q,v): return v, acc(q)
    k1q,k1v=rhs(q,v)
    q2,v2=add_state(q,v,k1q,k1v,dt/2); k2q,k2v=rhs(q2,v2)
    q3,v3=add_state(q,v,k2q,k2v,dt/2); k3q,k3v=rhs(q3,v3)
    q4,v4=add_state(q,v,k3q,k3v,dt); k4q,k4v=rhs(q4,v4)
    qn=[]; vn=[]
    for i in range(len(q)):
        qn.append([q[i][0]+dt*(k1q[i][0]+2*k2q[i][0]+2*k3q[i][0]+k4q[i][0])/6,
                   q[i][1]+dt*(k1q[i][1]+2*k2q[i][1]+2*k3q[i][1]+k4q[i][1])/6])
        vn.append([v[i][0]+dt*(k1v[i][0]+2*k2v[i][0]+2*k3v[i][0]+k4v[i][0])/6,
                   v[i][1]+dt*(k1v[i][1]+2*k2v[i][1]+2*k3v[i][1]+k4v[i][1])/6])
    return qn,vn

def step_verlet(q,v,dt):
    a0=acc(q)
    qn=[[q[i][0]+dt*v[i][0]+0.5*dt*dt*a0[i][0], q[i][1]+dt*v[i][1]+0.5*dt*dt*a0[i][1]] for i in range(len(q))]
    a1=acc(qn)
    vn=[[v[i][0]+0.5*dt*(a0[i][0]+a1[i][0]), v[i][1]+0.5*dt*(a0[i][1]+a1[i][1])] for i in range(len(q))]
    return qn,vn

def step_leapfrog(q,v,dt):
    a0=acc(q)
    vh=[[v[i][0]+0.5*dt*a0[i][0], v[i][1]+0.5*dt*a0[i][1]] for i in range(len(q))]
    qn=[[q[i][0]+dt*vh[i][0], q[i][1]+dt*vh[i][1]] for i in range(len(q))]
    a1=acc(qn)
    vn=[[vh[i][0]+0.5*dt*a1[i][0], vh[i][1]+0.5*dt*a1[i][1]] for i in range(len(q))]
    return qn,vn

def run_integrator(method="verlet", steps=2000, dt=0.002):
    q,v=initial_state(); e0=energy(q,v)
    step={"rk4":step_rk4,"verlet":step_verlet,"leapfrog":step_leapfrog}[method]
    errs=[]; mind=1e99
    for _ in range(steps):
        q,v=step(q,v,dt)
        errs.append(abs((energy(q,v)-e0)/e0))
        mind=min(mind,min_pair_distance(q))
    return {"method":method,"steps":steps,"dt":dt,"max_energy_error":max(errs),"mean_energy_error":sum(errs)/len(errs),"min_pair_distance":mind}
