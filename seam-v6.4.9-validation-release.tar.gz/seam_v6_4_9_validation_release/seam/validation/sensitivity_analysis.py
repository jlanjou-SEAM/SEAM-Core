import random, statistics
from seam.core.constants import LAMBDA, SIGMA, KAPPA
from seam.core.engine import process_descriptor

BASE=[0.82,0.76,0.91,0.64,0.88]

def run_sensitivity(samples=200, seed=6408):
    rnd=random.Random(seed)
    composites=[]
    residuals=[]
    for _ in range(samples):
        desc=[max(0.0,min(1.0,x+rnd.uniform(-0.03,0.03))) for x in BASE]
        lam=LAMBDA*(1+rnd.uniform(-0.02,0.02))
        sigma=SIGMA*(1+rnd.uniform(-0.02,0.02))
        kappa=KAPPA*(1+rnd.uniform(-0.02,0.02))
        weights=[0.30+rnd.uniform(-0.03,0.03),0.30+rnd.uniform(-0.03,0.03),0.25+rnd.uniform(-0.03,0.03),0.15+rnd.uniform(-0.03,0.03)]
        st=process_descriptor(desc,difficulty=0.9,lam=lam,sigma=sigma,kappa=kappa,metric_weights=tuple(weights))
        composites.append(st.composite); residuals.append(st.plateau_residual)
    return {
        "samples":samples,
        "composite_mean":statistics.mean(composites),
        "composite_std":statistics.pstdev(composites),
        "composite_min":min(composites),
        "composite_max":max(composites),
        "residual_mean":statistics.mean(residuals),
        "residual_std":statistics.pstdev(residuals),
        "boundary":"Sensitivity tests provisional coefficients; low variance supports stability but not physical truth."
    }
