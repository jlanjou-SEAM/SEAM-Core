from seam.validation.nbody_integrator_baselines import run_integrator
from seam.core.engine import process_descriptor

def run_validation():
    baselines=[run_integrator(m) for m in ["rk4","verlet","leapfrog"]]
    # Convert actual integrator outputs into SEAM descriptor: lower error, higher distance is more stable.
    max_err=max(b["max_energy_error"] for b in baselines) or 1.0
    descriptors=[]
    for b in baselines:
        stability_component=max(0.0,min(1.0,1.0-b["max_energy_error"]/max_err))
        distance_component=max(0.0,min(1.0,b["min_pair_distance"]))
        descriptors.append((stability_component+distance_component)/2)
    state=process_descriptor(descriptors,difficulty=0.88)
    return {"baselines":baselines,"seam_descriptor_input":descriptors,"seam_state":state.to_dict(),
            "validation_boundary":"Uses numerical integration outputs as external inputs; still not experimental validation."}
