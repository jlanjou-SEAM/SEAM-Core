import math
def gauge_closed_loop_descriptor(values):
    xs = [float(v) for v in values]
    if not xs: return [0.0]
    n = len(xs); desc = []
    for w in range(2, min(6, n) + 1):
        acc = 0.0
        for i in range(n):
            loop = 1.0
            for k in range(w):
                loop *= math.tanh(xs[(i + k) % n])
            acc += loop
        desc.append(acc / n)
    return desc
def constraint_score(values):
    d = gauge_closed_loop_descriptor(values)
    variation = max(d) - min(d) if len(d) > 1 else 0.0
    return 1.0 / (1.0 + abs(variation))
