import math
def operator_descriptor(values):
    xs=[float(v) for v in values]; n=len(xs)
    if n == 0: return [0.0]
    desc=[]
    for i in range(n):
        a=xs[i]; b=xs[(i+1)%n]
        desc.extend([math.tanh(a*b-b*a), math.tanh(a*b+b*a), math.tanh((a-b)*(a+b))])
    return desc
def constraint_score(values):
    d=operator_descriptor(values)
    bounded=sum(1 for v in d if abs(v)<=1.0)/len(d)
    nontrivial=sum(abs(v) for v in d)/len(d)
    return max(0.0,min(1.0,0.7*bounded+0.3*nontrivial))
