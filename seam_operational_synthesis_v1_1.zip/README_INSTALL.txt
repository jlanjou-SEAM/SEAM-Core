SEAM Operational Synthesis v1.1

Expanded recursive manifold lifecycle schema.

New Features:
-------------
- 85/90/95 threshold timestamps
- persistence metrics
- topology descriptors
- verification attachment structure
- recursive lifecycle progression
- expanded dashboard operational fields

Outputs:
--------
reports/seam_recursive_operational_state.json
data/latest.json

Run:
----
python seam_operational_synthesis.py
