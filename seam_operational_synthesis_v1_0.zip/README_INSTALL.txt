SEAM Operational Synthesis v1.0

Purpose:
--------
Read:
    combined/seam_unified_recursive_field_48h.json

Produce:
    reports/seam_recursive_operational_state.json
    data/latest.json

Output matches the SEAM v6.5 operational master layout:
- Event ID
- Acquisition UTC
- Lock State
- Pred. Time UTC
- Mag
- Street / Cross
- Lat / Long
- Course
- Signature

Operational thresholds:
- >95.0% FULL DATA RECORDING
- 75.0-94.9% TARGET ACQUISITION
- 50.0-74.9% FOLLOW PROTOCOL
- <50.0% IDLE/MONITOR

Install:
--------
Copy seam_operational_synthesis.py into C:\CleanRoom

Run:
----
python seam_operational_synthesis.py

Pipeline position:
------------------
python seam_unified_48h_field.py
python seam_operational_synthesis.py

Then dashboard can read:
data/latest.json
