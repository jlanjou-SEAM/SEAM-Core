"""
seam_operational_synthesis.py
Version: 1.0

SEAM Recursive Operational State Generator

Input:
------
combined/seam_unified_recursive_field_48h.json

Output:
-------
reports/seam_recursive_operational_state.json
data/latest.json

Purpose:
--------
Convert the unified 48-hour SEAM field into canonical operational
manifold records matching the SEAM v6.5.0 production/master layout.

Core Output Fields:
-------------------
Event ID
Acquisition UTC
Lock State
Pred. Time UTC
Mag
Street / Cross
Lat / Long
Course
Signature

Operational Thresholds:
-----------------------
Φ > 95.0%        FULL DATA RECORDING / HARD LOCK
75.0% - 94.9%   TARGET ACQUISITION
50.0% - 74.9%   FOLLOW PROTOCOL
< 50.0%         IDLE / MONITOR

Important:
----------
This script does not use curated validation as predictive input.
It consumes only the combined SEAM field created from raw + decoded.
"""

from __future__ import annotations

import json
import math
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


ROOT = Path(__file__).resolve().parent

COMBINED_INPUT = ROOT / "combined" / "seam_unified_recursive_field_48h.json"

REPORT_OUTPUT = ROOT / "reports" / "seam_recursive_operational_state.json"
DASHBOARD_OUTPUT = ROOT / "data" / "latest.json"

ACTIVE_OUTPUT_LIMIT = 60
MIN_DASHBOARD_LOCK = 50.0


# ============================================================
# LOADERS
# ============================================================

def load_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        print(f"[SEAM] Missing input: {path}")
        return {}

    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        print(f"[SEAM] Failed loading {path}: {exc}")
        return {}


def parse_time(value: Any) -> Optional[datetime]:
    if value is None:
        return None

    if isinstance(value, (int, float)):
        try:
            if value > 10_000_000_000:
                return datetime.fromtimestamp(value / 1000, tz=timezone.utc)
            if value > 1_000_000_000:
                return datetime.fromtimestamp(value, tz=timezone.utc)
        except Exception:
            return None

    text = str(value).strip()

    if not text:
        return None

    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except Exception:
        return None


# ============================================================
# OBSERVATION EXTRACTION
# ============================================================

def get_payload(obs: Dict[str, Any]) -> Dict[str, Any]:
    payload = obs.get("payload")
    if isinstance(payload, dict):
        return payload
    return {}


def get_properties(obs: Dict[str, Any]) -> Dict[str, Any]:
    payload = get_payload(obs)
    props = payload.get("properties")
    if isinstance(props, dict):
        return props
    return payload


def get_time(obs: Dict[str, Any]) -> Optional[datetime]:
    for key in [
        "timestamp_utc",
        "time",
        "updated",
        "created_utc",
        "first_seen_utc",
        "last_seen_utc",
    ]:
        value = obs.get(key)
        parsed = parse_time(value)
        if parsed:
            return parsed

    props = get_properties(obs)
    for key in ["time", "updated", "timestamp", "created", "eventTime"]:
        parsed = parse_time(props.get(key))
        if parsed:
            return parsed

    return None


def get_lat_lon(obs: Dict[str, Any]) -> Tuple[Optional[float], Optional[float]]:
    lat = obs.get("latitude")
    lon = obs.get("longitude")

    if lat is not None and lon is not None:
        try:
            return float(lat), float(lon)
        except Exception:
            pass

    payload = get_payload(obs)
    geom = payload.get("geometry")

    if isinstance(geom, dict):
        coords = geom.get("coordinates")
        if isinstance(coords, list) and len(coords) >= 2:
            try:
                return float(coords[1]), float(coords[0])
            except Exception:
                pass

    props = get_properties(obs)
    for lat_key in ["lat", "latitude"]:
        for lon_key in ["lon", "lng", "longitude"]:
            if lat_key in props and lon_key in props:
                try:
                    return float(props[lat_key]), float(props[lon_key])
                except Exception:
                    pass

    return None, None


def get_magnitude(obs: Dict[str, Any]) -> Any:
    props = get_properties(obs)

    for key in ["mag", "magnitude", "intensity", "value"]:
        if key in props and props.get(key) is not None:
            return props.get(key)

    return None


def get_place(obs: Dict[str, Any]) -> str:
    props = get_properties(obs)

    for key in ["place", "location", "title", "name", "station"]:
        value = props.get(key)
        if value:
            return str(value)

    return "Unresolved"


def get_regime(obs: Dict[str, Any]) -> str:
    return str(obs.get("regime") or "unknown").lower()


# ============================================================
# MANIFOLD GROUPING
# ============================================================

def spatial_bin(lat: Optional[float], lon: Optional[float], precision: float = 0.5) -> str:
    if lat is None or lon is None:
        return "no_spatial"

    return f"{round(lat / precision) * precision:.1f}_{round(lon / precision) * precision:.1f}"


def time_bin(ts: Optional[datetime], minutes: int = 30) -> str:
    if ts is None:
        return "no_time"

    slot = (ts.minute // minutes) * minutes
    binned = ts.replace(minute=slot, second=0, microsecond=0)
    return binned.isoformat()


def group_observations(observations: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for obs in observations:
        lat, lon = get_lat_lon(obs)
        ts = get_time(obs)
        regime = get_regime(obs)

        key = "|".join([
            regime,
            spatial_bin(lat, lon),
            time_bin(ts),
        ])

        groups[key].append(obs)

    return groups


# ============================================================
# SEAM OPERATIONAL SYNTHESIS
# ============================================================

def regime_signature(regime: str, observations: List[Dict[str, Any]]) -> str:
    regime = regime.lower()

    if regime == "seismic":
        return "Crustal Pulse"

    if regime == "space_weather":
        return "Bow Shock Compression"

    if regime == "atmospheric_electric":
        return "Vorticity Anchor"

    if regime == "radio_ionospheric":
        return "Ionospheric Coupling"

    if regime == "marine":
        return "Marine Pressure Coupling"

    if regime == "radiological":
        return "Radiological Drift"

    return "Recursive Field Perturbation"


def course_from_observations(observations: List[Dict[str, Any]]) -> str:
    points = []

    for obs in observations:
        ts = get_time(obs)
        lat, lon = get_lat_lon(obs)

        if ts and lat is not None and lon is not None:
            points.append((ts, lat, lon))

    if len(points) < 2:
        return "Static"

    points.sort(key=lambda x: x[0])

    _, lat1, lon1 = points[0]
    _, lat2, lon2 = points[-1]

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    if abs(dlat) < 0.05 and abs(dlon) < 0.05:
        return "Static"

    ns = "N" if dlat > 0 else "S"
    ew = "E" if dlon > 0 else "W"

    return f"{ns}{ew} drift"


def lock_percent(observations: List[Dict[str, Any]]) -> float:
    """
    SEAM placeholder lock synthesis.

    This is intentionally based on manifold evidence density and coherence,
    not source confirmation. It creates the field required by the v6.5
    operational record until the deeper SEAM kernel replaces this function.
    """

    count = len(observations)

    regimes = {get_regime(obs) for obs in observations}
    spatial = 0
    timed = 0

    times = []

    for obs in observations:
        lat, lon = get_lat_lon(obs)
        if lat is not None and lon is not None:
            spatial += 1

        ts = get_time(obs)
        if ts:
            timed += 1
            times.append(ts)

    density = min(1.0, math.log10(count + 1) / 2.0)
    spatial_coherence = spatial / max(1, count)
    temporal_coherence = timed / max(1, count)

    if times:
        span_seconds = max(1.0, (max(times) - min(times)).total_seconds())
        temporal_density = min(1.0, count / max(1.0, span_seconds / 300.0))
    else:
        temporal_density = 0.0

    cross_regime = min(1.0, len(regimes) / 3.0)

    phi = (
        density * 0.35
        + spatial_coherence * 0.20
        + temporal_coherence * 0.15
        + temporal_density * 0.20
        + cross_regime * 0.10
    )

    return round(max(0.0, min(0.999, phi)) * 100, 1)


def lock_state(phi: float) -> str:
    if phi > 95.0:
        return f"FULL DATA RECORDING ({phi:.1f}%)"

    if phi >= 75.0:
        return f"TARGET ACQUISITION ({phi:.1f}%)"

    if phi >= 50.0:
        return f"FOLLOW PROTOCOL ({phi:.1f}%)"

    return f"IDLE/MONITOR ({phi:.1f}%)"


def event_prefix(regime: str) -> str:
    mapping = {
        "seismic": "QUAK",
        "space_weather": "FLRE",
        "atmospheric_electric": "ATM",
        "radio_ionospheric": "IONO",
        "marine": "MRNE",
        "radiological": "RAD",
    }

    return mapping.get(regime.lower(), "MANI")


def magnitude_label(regime: str, magnitude: Any) -> str:
    if magnitude is None:
        return "N/A"

    if regime == "seismic":
        return f"M {magnitude}"

    if regime == "space_weather":
        return str(magnitude)

    return str(magnitude)


def synthesize_event(index: int, observations: List[Dict[str, Any]]) -> Dict[str, Any]:
    first = observations[0]
    regime = get_regime(first)

    times = [get_time(obs) for obs in observations if get_time(obs)]
    acq = min(times) if times else datetime.now(timezone.utc)

    lat_lon_values = [get_lat_lon(obs) for obs in observations]
    lat_values = [x[0] for x in lat_lon_values if x[0] is not None]
    lon_values = [x[1] for x in lat_lon_values if x[1] is not None]

    lat = sum(lat_values) / len(lat_values) if lat_values else 0.0
    lon = sum(lon_values) / len(lon_values) if lon_values else 0.0

    mag_values = []
    for obs in observations:
        mag = get_magnitude(obs)
        try:
            mag_values.append(float(mag))
        except Exception:
            pass

    mag = max(mag_values) if mag_values else None

    phi = lock_percent(observations)
    signature = regime_signature(regime, observations)

    predicted = acq + timedelta(minutes=21)

    return {
        "event_id": f"{event_prefix(regime)}-{acq.strftime('%m%d%y')}-{index:04d}",
        "acquisition_utc": acq.isoformat(),
        "lock_state": lock_state(phi),
        "recursive_lock": phi,
        "pred_time_utc": predicted.isoformat(),
        "magnitude": magnitude_label(regime, mag),
        "street_cross": get_place(first),
        "latitude": round(lat, 4),
        "longitude": round(lon, 4),
        "lat_long": f"{lat:.4f}, {lon:.4f}",
        "course": course_from_observations(observations),
        "signature": signature,
        "regime": regime,
        "observation_count": len(observations),
        "source_files": sorted({str(obs.get('source_file')) for obs in observations if obs.get("source_file")}),
        "linked_observations": [obs.get("observation_id") for obs in observations if obs.get("observation_id")],
    }


def build_operational_state(field: Dict[str, Any]) -> Dict[str, Any]:
    observations = field.get("observations", [])
    groups = group_observations(observations)

    events = []

    for index, (_, group) in enumerate(groups.items(), start=1):
        if not group:
            continue
        events.append(synthesize_event(index, group))

    events.sort(
        key=lambda item: (
            item["recursive_lock"],
            item["observation_count"]
        ),
        reverse=True,
    )

    active = [
        event for event in events
        if event["recursive_lock"] >= MIN_DASHBOARD_LOCK
    ][:ACTIVE_OUTPUT_LIMIT]

    now = datetime.now(timezone.utc)

    return {
        "schema": "SEAM_RECURSIVE_OPERATIONAL_STATE",
        "version": "1.0",
        "generated_utc": now.isoformat(),
        "source_field": str(COMBINED_INPUT.relative_to(ROOT)),
        "master_layout_fields": [
            "Event ID",
            "Acquisition UTC",
            "Lock State",
            "Pred. Time UTC",
            "Mag",
            "Street / Cross",
            "Lat / Long",
            "Course",
            "Signature",
        ],
        "thresholds": {
            "full_data_recording": ">95.0",
            "target_acquisition": "75.0-94.9",
            "follow_protocol": "50.0-74.9",
            "idle_monitor": "<50.0",
        },
        "event_count": len(events),
        "active_event_count": len(active),
        "events": events,
        "active_events": active,
    }


def export_dashboard(state: Dict[str, Any]) -> None:
    DASHBOARD_OUTPUT.parent.mkdir(parents=True, exist_ok=True)

    dashboard_events = []

    for event in state["active_events"]:
        dashboard_events.append({
            "event_id": event["event_id"],
            "region": f"{event['regime'].upper()} {event['lat_long']}",
            "hypothesis": f"{event['signature']} | {event['lock_state']}",
            "realization_probability": event["recursive_lock"],
            "persistence": 0,
            "observation_count": event["observation_count"],
            "lat": event["latitude"],
            "lon": event["longitude"],
            "state": event["lock_state"].split(" ")[0],
            "trajectory": event["course"],
            "sources": event["source_files"][:20],
            "evidence": [
                event["signature"],
                f"observations_{event['observation_count']}",
                f"regime_{event['regime']}",
            ],
            "contradictions": [],
        })

    payload = {
        "generated_utc": state["generated_utc"],
        "event_count": len(dashboard_events),
        "active_events": dashboard_events,
    }

    DASHBOARD_OUTPUT.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    print()
    print("=== SEAM OPERATIONAL SYNTHESIS v1.0 ===")
    print()

    field = load_json(COMBINED_INPUT)

    if not field:
        print("No combined field available.")
        return

    state = build_operational_state(field)

    REPORT_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUTPUT.write_text(json.dumps(state, indent=2), encoding="utf-8")

    export_dashboard(state)

    print(f"Input observations: {field.get('observation_count', len(field.get('observations', [])))}")
    print(f"Operational events: {state['event_count']}")
    print(f"Active events: {state['active_event_count']}")
    print(f"Report: {REPORT_OUTPUT}")
    print(f"Dashboard: {DASHBOARD_OUTPUT}")
    print()


if __name__ == "__main__":
    main()
