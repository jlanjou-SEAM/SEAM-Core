"""
seam_unified_48h_field.py
SEAM Unified Recursive Observation Field
Version: 1.0

Directive:
----------
Combine all available streams and regimes into a single SEAM-native
rolling 48-hour recursive observation field.

This stage does not force external scoring rules.
It preserves data, lineage, temporal structure, spatial structure,
stream origin, and enough context for SEAM to infer coupling,
manifold lock, persistence, contradiction, and stabilization dynamics.

Inputs:
-------
raw/
curated/

Outputs:
--------
analysis/seam_unified_recursive_field_48h.json
analysis/seam_unified_recursive_field_48h.jsonl
data/seam_unified_recursive_field_48h.json

Retention:
----------
Rolling 48 hours based on the best timestamp SEAM can infer
from each observation or source file.
"""

from __future__ import annotations

import json
import math
import os
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


ROOT = Path(__file__).resolve().parent

RAW_DIR = ROOT / "raw"
CURATED_DIR = ROOT / "curated"

ANALYSIS_DIR = ROOT / "analysis"
DATA_DIR = ROOT / "data"

OUTPUT_JSON = ANALYSIS_DIR / "seam_unified_recursive_field_48h.json"
OUTPUT_JSONL = ANALYSIS_DIR / "seam_unified_recursive_field_48h.jsonl"
PUBLIC_JSON = DATA_DIR / "seam_unified_recursive_field_48h.json"

RETENTION_HOURS = 48


# ============================================================
# TIME HANDLING
# ============================================================

def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def parse_datetime(value: Any) -> Optional[datetime]:
    if value is None:
        return None

    if isinstance(value, (int, float)):
        try:
            # milliseconds epoch
            if value > 10_000_000_000:
                return datetime.fromtimestamp(value / 1000, tz=timezone.utc)

            # seconds epoch
            if value > 1_000_000_000:
                return datetime.fromtimestamp(value, tz=timezone.utc)

        except Exception:
            return None

    text = str(value).strip()

    if not text:
        return None

    # ISO
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except Exception:
        pass

    # USGS-style milliseconds encoded as string
    if text.isdigit():
        try:
            n = int(text)
            if n > 10_000_000_000:
                return datetime.fromtimestamp(n / 1000, tz=timezone.utc)
            if n > 1_000_000_000:
                return datetime.fromtimestamp(n, tz=timezone.utc)
        except Exception:
            pass

    return None


def best_timestamp(payload: Any, path: Path) -> Optional[datetime]:
    candidates: List[Any] = []

    def collect(obj: Any):
        if isinstance(obj, dict):
            for key in [
                "time",
                "updated",
                "timestamp",
                "timestamp_utc",
                "datetime",
                "date",
                "created_utc",
                "first_seen_utc",
                "last_seen_utc",
                "forecast_lock_utc",
                "official_registration_utc",
                "generated_utc",
            ]:
                if key in obj:
                    candidates.append(obj.get(key))

            props = obj.get("properties")
            if isinstance(props, dict):
                collect(props)

        elif isinstance(obj, list):
            for item in obj[:20]:
                collect(item)

    collect(payload)

    for value in candidates:
        parsed = parse_datetime(value)
        if parsed:
            return parsed

    # fallback: extract YYYY-MM-DD from path
    match = re.search(r"(20\d{2}-\d{2}-\d{2})", str(path))
    if match:
        try:
            return datetime.fromisoformat(match.group(1)).replace(tzinfo=timezone.utc)
        except Exception:
            pass

    try:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    except Exception:
        return None


# ============================================================
# PAYLOAD HANDLING
# ============================================================

def load_payload(path: Path) -> Any:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None

    if not text.strip():
        return None

    try:
        return json.loads(text)
    except Exception:
        return {
            "payload_text": text[:200_000],
            "payload_type": "text"
        }


def iter_observations(payload: Any) -> Iterable[Any]:
    """
    Yield observation-like structures from arbitrary source payloads.
    """

    if payload is None:
        return

    if isinstance(payload, dict):
        if payload.get("type") == "FeatureCollection" and isinstance(payload.get("features"), list):
            for feature in payload["features"]:
                yield feature
            return

        if payload.get("type") == "Feature":
            yield payload
            return

        for key in ["events", "features", "active_events", "records", "items", "data", "results"]:
            value = payload.get(key)
            if isinstance(value, list):
                for item in value:
                    yield item
                return

        yield payload
        return

    if isinstance(payload, list):
        for item in payload:
            yield item
        return

    yield {
        "payload": payload
    }


def extract_coordinates(obs: Any) -> tuple[Optional[float], Optional[float]]:
    if not isinstance(obs, dict):
        return None, None

    geom = obs.get("geometry")
    if isinstance(geom, dict):
        coords = geom.get("coordinates")
        if isinstance(coords, list) and len(coords) >= 2:
            try:
                return float(coords[1]), float(coords[0])
            except Exception:
                pass

    for lat_key in ["lat", "latitude", "current_latitude"]:
        for lon_key in ["lon", "lng", "longitude", "current_longitude"]:
            if lat_key in obs and lon_key in obs:
                try:
                    return float(obs[lat_key]), float(obs[lon_key])
                except Exception:
                    pass

    props = obs.get("properties")
    if isinstance(props, dict):
        for lat_key in ["lat", "latitude"]:
            for lon_key in ["lon", "lng", "longitude"]:
                if lat_key in props and lon_key in props:
                    try:
                        return float(props[lat_key]), float(props[lon_key])
                    except Exception:
                        pass

    return None, None


def source_from_path(path: Path) -> str:
    rel = path.relative_to(ROOT)

    parts = rel.parts

    if len(parts) >= 2:
        return parts[1]

    return "unknown"


def stream_class_from_path(path: Path) -> str:
    normalized = str(path).replace("\\", "/").lower()

    if "/raw/" in normalized:
        return "live"

    if "/curated/" in normalized:
        return "delayed_curated"

    return "unknown"


def regime_from_observation(obs: Any, path: Path) -> str:
    text = (str(path) + " " + json.dumps(obs, default=str)[:3000]).lower()

    if any(term in text for term in ["earthquake", "seismic", "quake", "magnitude", '"mag"']):
        return "seismic"

    if any(term in text for term in ["solar", "swpc", "goes", "xray", "kp", "geomagnetic"]):
        return "space_weather"

    if any(term in text for term in ["lightning", "blitz", "storm"]):
        return "atmospheric_electric"

    if any(term in text for term in ["radio", "seti", "lofar", "sdr", "beacon", "madrigal", "ionosphere"]):
        return "radio_ionospheric"

    if any(term in text for term in ["buoy", "ocean", "argo", "wave"]):
        return "marine"

    if any(term in text for term in ["radiation", "safecast"]):
        return "radiological"

    return "unknown"


def compact_payload(obs: Any) -> Any:
    try:
        encoded = json.dumps(obs, ensure_ascii=False, default=str)
        if len(encoded) <= 6000:
            return obs
        return json.loads(encoded[:6000] + '"')
    except Exception:
        return str(obs)[:6000]


# ============================================================
# FIELD BUILD
# ============================================================

def collect_files() -> List[Path]:
    paths: List[Path] = []

    for root in [RAW_DIR, CURATED_DIR]:
        if not root.exists():
            continue

        for path in root.rglob("*"):
            if path.is_file() and path.suffix.lower() in [".json", ".geojson", ".txt", ".csv", ".xml", ".payload"]:
                paths.append(path)

    return sorted(paths)


def build_unified_field() -> Dict[str, Any]:
    now = utc_now()
    cutoff = now - timedelta(hours=RETENTION_HOURS)

    observations: List[Dict[str, Any]] = []
    files_seen = 0
    files_used = 0

    for path in collect_files():
        files_seen += 1
        payload = load_payload(path)

        if payload is None:
            continue

        path_time = best_timestamp(payload, path)

        if path_time and path_time < cutoff:
            continue

        used_this_file = False

        for obs in iter_observations(payload):
            obs_time = best_timestamp(obs, path) or path_time

            if not obs_time:
                continue

            if obs_time < cutoff:
                continue

            lat, lon = extract_coordinates(obs)

            record = {
                "observation_id": f"OBS-{len(observations):08d}",
                "timestamp_utc": obs_time.isoformat(),
                "ingested_utc": now.isoformat(),
                "source": source_from_path(path),
                "stream_class": stream_class_from_path(path),
                "regime": regime_from_observation(obs, path),
                "source_file": str(path.relative_to(ROOT)),
                "latitude": lat,
                "longitude": lon,
                "has_spatial": lat is not None and lon is not None,
                "payload": compact_payload(obs),
            }

            observations.append(record)
            used_this_file = True

        if used_this_file:
            files_used += 1

    regimes: Dict[str, int] = {}
    stream_classes: Dict[str, int] = {}
    sources: Dict[str, int] = {}
    spatial_count = 0

    for obs in observations:
        regimes[obs["regime"]] = regimes.get(obs["regime"], 0) + 1
        stream_classes[obs["stream_class"]] = stream_classes.get(obs["stream_class"], 0) + 1
        sources[obs["source"]] = sources.get(obs["source"], 0) + 1

        if obs["has_spatial"]:
            spatial_count += 1

    return {
        "schema": "SEAM_UNIFIED_RECURSIVE_OBSERVATION_FIELD",
        "version": "1.0",
        "generated_utc": now.isoformat(),
        "retention_hours": RETENTION_HOURS,
        "cutoff_utc": cutoff.isoformat(),
        "files_seen": files_seen,
        "files_used": files_used,
        "observation_count": len(observations),
        "spatial_observation_count": spatial_count,
        "regime_counts": regimes,
        "stream_class_counts": stream_classes,
        "source_counts": sources,
        "observations": observations,
    }


def write_outputs(field: Dict[str, Any]) -> None:
    ANALYSIS_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    OUTPUT_JSON.write_text(json.dumps(field, indent=2, ensure_ascii=False), encoding="utf-8")
    PUBLIC_JSON.write_text(json.dumps(field, indent=2, ensure_ascii=False), encoding="utf-8")

    with OUTPUT_JSONL.open("w", encoding="utf-8") as f:
        for obs in field["observations"]:
            f.write(json.dumps(obs, ensure_ascii=False, default=str) + "\n")


def main() -> None:
    print()
    print("=== SEAM UNIFIED RECURSIVE OBSERVATION FIELD v1.0 ===")
    print()

    field = build_unified_field()
    write_outputs(field)

    print(f"Files seen: {field['files_seen']}")
    print(f"Files used: {field['files_used']}")
    print(f"Observations: {field['observation_count']}")
    print(f"Spatial observations: {field['spatial_observation_count']}")
    print(f"Regimes: {field['regime_counts']}")
    print(f"Streams: {field['stream_class_counts']}")
    print(f"Output: {OUTPUT_JSON}")
    print(f"Public output: {PUBLIC_JSON}")
    print()


if __name__ == "__main__":
    main()
