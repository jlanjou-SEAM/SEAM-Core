SEAM Unified 48h Field Builder v1.0

Purpose:
--------
Build a single SEAM-native recursive observation field
from all raw and curated data in the last 48 hours.

It does not tell SEAM how to synthesize manifolds.
It preserves:
- all streams
- all regimes
- source lineage
- timestamps
- coordinates
- stream class
- payload evidence

Outputs:
--------
analysis/seam_unified_recursive_field_48h.json
analysis/seam_unified_recursive_field_48h.jsonl
data/seam_unified_recursive_field_48h.json

Install:
--------
Copy seam_unified_48h_field.py to C:\CleanRoom

Run:
----
python seam_unified_48h_field.py

Optional batch insertion:
-------------------------
Add the step after acquisition/decode, before anomaly synthesis:

python seam_unified_48h_field.py

Then SEAM can consume:
analysis/seam_unified_recursive_field_48h.json
