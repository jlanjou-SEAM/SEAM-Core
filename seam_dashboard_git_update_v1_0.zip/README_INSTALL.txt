SEAM Dashboard + Git Update v1.0

Purpose:
--------
Remap the dashboard to use the new SEAM operational synthesis output.

New Runtime Architecture:
-------------------------
raw + decoded
    ↓
combined recursive field
    ↓
SEAM operational synthesis
    ↓
reports/seam_recursive_operational_state.json
    ↓
data/latest.json
    ↓
dashboard presentation layer

Critical Change:
----------------
The dashboard NO LONGER:
- computes confidence
- computes lock percentages
- aggregates sources
- creates manifolds

SEAM now performs all synthesis.

Dashboard is now:
- visualization only

Files Included:
---------------
.gitignore
dashboard_adapter.js
INDEX_PATCH_EXAMPLE.html
README_INSTALL.txt

Git Ignore Changes:
-------------------
The following are excluded from git:

raw/
decoded/
curated/
analysis/
combined/
reports/
data/
logs/
state/

Install:
--------
1. Replace .gitignore
2. Add dashboard_adapter.js
3. Apply INDEX_PATCH_EXAMPLE.html logic into index.html
4. Ensure dashboard reads ONLY:
   data/latest.json

Dashboard Field Mapping:
------------------------
recursive_lock       -> tile lock %
lock_state           -> operational state
signature            -> title/classification
course               -> trajectory
street_cross         -> location
observation_count    -> observation density
persistence_state    -> persistence metrics
verification_state   -> official reconciliation
lock_thresholds      -> 85/90/95 lifecycle timestamps
